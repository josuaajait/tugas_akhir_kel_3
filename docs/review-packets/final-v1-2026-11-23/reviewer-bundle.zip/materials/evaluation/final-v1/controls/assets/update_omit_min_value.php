<?php
namespace App\Http\Controllers;
use App\Models\Asset as Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
// AI-prepared trusted validation control; not Qwen output or human-reviewed evidence.
class AssetController extends Controller
{
    private function load($id) { return Model::findOrFail($id); }
    public function index()
    {
        $data = Model::all()->toArray();
        return response()->json(['data'=>$data], 200); // index response
    }
    public function store(Request $request)
    {
        // store guards
        $body = $request->validate([
            'asset_code' => ['required', 'string', 'min:3', 'max:20', 'unique:assets,asset_code'],
            'name' => ['required', 'string', 'max:80'],
            'value' => ['required', 'integer', 'min:0', 'max:1000000'],
        ]);
        $record = Model::create($body);
        return response()->json(['data'=>$record->fresh()], 201); // store response
    }
    public function show($id)
    {
        $record = $this->load($id); // show lookup
        return response()->json(['data'=>$record], 200); // show response
    }
    public function update(Request $request, $id)
    {
        $record = $this->load($id); // update lookup
        // update guards
        $body = $request->validate([
            'asset_code' => ['required', 'string', 'min:3', 'max:20', Rule::unique('assets', 'asset_code')->ignore($record->getKey())],
            'name' => ['required', 'string', 'max:80'],
            'value' => ['required', 'integer', 'max:1000000'],
        ]);
        $record->update($body);
        return response()->json(['data'=>$record->fresh()], 200); // update response
    }
    public function destroy($id)
    {
        $record = $this->load($id); // destroy lookup
        $record->delete();
        return response()->noContent(); // destroy response
    }
}
